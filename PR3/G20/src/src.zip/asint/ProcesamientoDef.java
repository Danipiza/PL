package asint;


import asint.SintaxisAbstractaTiny.*;


public class ProcesamientoDef implements Procesamiento {

	@Override
	public void procesa(Prog prog) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Bloq bloq) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Si_decs si_decs) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(No_decs no_decs) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Si_instrs si_instrs) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(No_instrs no_instrs) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Si_tipo si_tipo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(No_tipo no_tipo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Tipo_lista tipo_lista) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Tipo_circum tipo_circum) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Tipo_struct tipo_struct) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Tipo_iden tipo_iden) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Tipo_int tipo_int) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Tipo_real tipo_real) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Tipo_bool tipo_bool) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Tipo_string tipo_string) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Muchos_campos muchos_campos) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Un_campo un_campo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Crea_campo crea_campo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Muchas_decs muchas_decs) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Una_dec una_dec) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Dec_variable dec_variable) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Dec_tipo dec_tipo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Dec_proc dec_proc) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Si_parsF si_parsF) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(No_parsF no_parsF) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Muchos_parsF muchos_parsF) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Un_parF un_parF) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(ParamF paramF) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Param param) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Muchas_instrs muchas_instrs) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Una_instr una_instr) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Instr_eval instr_eval) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Instr_if instr_if) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Instr_ifelse instr_ifelse) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Instr_while instr_while) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Instr_read instr_read) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Instr_write instr_write) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Instr_nl instr_nl) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Instr_new instr_new) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Instr_del instr_del) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Instr_call instr_call) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Instr_bloque instr_bloque) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Si_parsRe si_parsRe) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(No_parsRe no_parsRe) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Muchos_parsRe muchos_parsRe) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Un_parRe un_parRe) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Suma suma) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Resta resta) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Mul mul) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Div div) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Asig asig) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(MenorI menorI) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Menor menor) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(MayorI mayorI) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Mayor mayor) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Igual igual) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Distint distint) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(And and) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Or or) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Negacion negacion) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(MenosUnario menosUnario) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Indexacion indexacion) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Acceso acceso) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Indireccion indireccion) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Iden iden) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Lit_ent lit_ent) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Lit_real lit_real) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(TRUE true1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(FALSE false1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Lit_cadena lit_cadena) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(NULL null1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procesa(Mod mod) {
		// TODO Auto-generated method stub
		
	}

	
    
}
